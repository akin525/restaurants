const icons = [
    'fa-user', 'fa-home', 'fa-cog', 'fa-bell', 'fa-envelope',
    'fa-star', 'fa-heart', 'fa-thumbs-up', 'fa-comment', 'fa-share',
    'fa-search', 'fa-camera', 'fa-image', 'fa-video', 'fa-music',
    'fa-file', 'fa-folder', 'fa-download', 'fa-upload', 'fa-trash',
    'fa-edit', 'fa-save', 'fa-print', 'fa-link', 'fa-unlink',
    'fa-lock', 'fa-unlock', 'fa-key', 'fa-tag', 'fa-tags',
    'fa-calendar', 'fa-clock', 'fa-map-marker', 'fa-phone', 'fa-globe',
    'fa-wifi', 'fa-battery-full', 'fa-signal', 'fa-microphone', 'fa-volume-up',
    'fa-camera-retro', 'fa-picture-o', 'fa-photo', 'fa-pencil', 'fa-paint-brush',
    'fa-magic', 'fa-gift', 'fa-leaf', 'fa-fire', 'fa-plane',
    'fa-truck', 'fa-ship', 'fa-bicycle', 'fa-bus', 'fa-car',
    'fa-train', 'fa-subway', 'fa-rocket', 'fa-space-shuttle', 'fa-motorcycle'
];
