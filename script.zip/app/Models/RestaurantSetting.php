<?php

namespace App\Models;

use App\Models\BaseModel;

class RestaurantSetting extends BaseModel
{
    protected $guarded = ['id'];
}
