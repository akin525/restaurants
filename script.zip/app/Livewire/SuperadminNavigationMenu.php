<?php

namespace App\Livewire;

use Livewire\Component;

class SuperadminNavigationMenu extends Component
{
    public function render()
    {
        return view('livewire.superadmin-navigation-menu');
    }
}
