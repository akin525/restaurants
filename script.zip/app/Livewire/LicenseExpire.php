<?php

namespace App\Livewire;

use Livewire\Component;

class LicenseExpire extends Component
{
    public function render()
    {
        return view('livewire.license-expire');
    }
}
