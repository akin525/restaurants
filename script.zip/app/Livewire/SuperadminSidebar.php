<?php

namespace App\Livewire;

use Livewire\Component;

class SuperadminSidebar extends Component
{
    public function render()
    {
        return view('livewire.superadmin-sidebar');
    }
}
