<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MenuCategoryController extends Controller
{
    //
}
